// Three chained 74HC595 (24 outputs) over hardware SPI, brightness through PWM on OE.
// MOSI -> SER of chip 0, SCK -> SRCLK of all, pin 10 -> RCLK of all, pin 9 -> OE of all,
// QH' of chip n -> SER of chip n+1.
#include <Shift595.h>

Shift595 chain(Shift595::Spi{10}, 3, 9);

void setup() {
  chain.begin();
  chain.brightness(64);
}

void loop() {
  static uint8_t pos = 0;
  chain.clear();
  chain.set(pos, true);                    // a running light over all 24 outputs
  chain.update();
  pos = (pos + 1) % 24;
  delay(60);
}
